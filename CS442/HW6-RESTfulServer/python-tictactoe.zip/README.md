Homework 6 - RESTful Server
===========================

**References:**

- [RESTful tutorial](http://gotofritz.net/blog/weekly-challenge/restful-python-api-bottle/)

**Requirements:**

1. Video game >= Tic Tac Toe
2. Python RESTful server

**Running the applet:**

    appletviewer -J"-Djava.security.policy=policy.txt" Client.html






